package com.example.a86136.mynote;

import android.app.ListActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;

import java.util.Collections;

public class List_activity extends ListActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_list_activity);
         Intent get_editext_one=getIntent();
         String new_get_editext_one=get_editext_one.getStringExtra("new_editext_one");
         ListAdapter adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,Collections.singletonList(new_get_editext_one));
         setListAdapter(adapter);


    }
}
