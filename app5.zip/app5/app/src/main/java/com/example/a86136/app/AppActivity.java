package com.example.a86136.app;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ViewAnimator;

public class AppActivity extends AppCompatActivity {
    TextView score1 ;
    TextView score2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app3);
         score1 = (TextView) findViewById(R.id.showscore);
        score2 = (TextView) findViewById(R.id.showscore2);
    }
    public void btn_1(View btn){if (btn.getId()==R.id.btn_1){showscore(1);}else{showscore2(1);} }
    public void btn_2(View btn){if (btn.getId()==R.id.btn_2){showscore(2);}else{showscore2(2);} }
    public void btn_3(View btn){if (btn.getId()==R.id.btn_3){showscore(3);}else{showscore2(3);} }
    public void reset1(View btn){score1.setText("0");}
    public void reset2(View btn){score2.setText("0");}
    private void showscore(int inc){
        String oldscore = (String)score1.getText();
        int newscore = Integer.parseInt(oldscore)+inc;
        score1.setText(""+newscore);
    }
    private void showscore2(int inc){
        String oldscore = (String)score2.getText();
        int newscore = Integer.parseInt(oldscore)+inc;
        score2.setText(""+newscore);

    }







}
