package com.example.a86136.mynote;

import android.app.ListActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class One extends AppCompatActivity {

    EditText eidtext_content;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_one);
        eidtext_content=(EditText)findViewById(R.id.Eidtext_content);
    }
      public  void btn_ok(View ok){
       String new_editext_content = eidtext_content.getText().toString();
       Intent intent = new Intent(this,List_activity.class);
       intent.putExtra("new_editext_one", new_editext_content);
       startActivity(intent);
  }

    @Override
    public boolean onCreatePanelMenu(int featureId, Menu menu) {
        getMenuInflater().inflate(R.menu.one_menu,menu);
        return super.onCreatePanelMenu(featureId, menu);
    }
}
