package com.example.a86136.app;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Temperature extends AppCompatActivity {
    TextView temptext;
    EditText tempedit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temperature);
        temptext=(TextView)findViewById(R.id.textView);
        tempedit=(EditText)findViewById(R.id.editView);
    }
    public void btnClick(View btn){
        String oldtemp= tempedit.getText().toString();
        double newtemp=Double.parseDouble(oldtemp)*1.8;
        temptext.setText(""+newtemp);
        }
}
