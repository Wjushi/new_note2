package com.example.a86136.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.provider.Telephony;
import android.renderscript.Sampler;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Rate extends AppCompatActivity {
    TextView Ratetext;
    EditText Rateedit;
    Float GBP=0.1f;
    Float RUB=0.2f;
    Float JPY=0.3f;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rate);
        Ratetext=(TextView)findViewById(R.id.textView2);
        Rateedit=(EditText)findViewById(R.id.eidt1);
        SharedPreferences sharedPreferences=getSharedPreferences("open",Activity.MODE_PRIVATE);
        GBP=sharedPreferences.getFloat("rate_GBP",0.0f);
        RUB=sharedPreferences.getFloat("rate_RUP",0.0f);
        JPY=sharedPreferences.getFloat("rate_JPY",0.0f);

;    }
    public void rateClick(View rate)
    {
         String rate2 = Rateedit.getText().toString();
         float r=0;
         float Rate;
         if(rate2.length()>0){
             r = Float.parseFloat(rate2);
         }
         if(rate.getId()==R.id.button2){
              Rate=r*GBP;
             Ratetext.setText(String.valueOf(Rate));
         }
        else if (rate.getId()==R.id.button3){
             Rate=r*RUB;
            Ratetext.setText(String.valueOf(Rate));
        }
        else {
             Rate=r*JPY;
            Ratetext.setText(String.valueOf(Rate));
        }}
     public void open(View op){
         Intent change= new Intent(this,Open.class);
         change.putExtra("GBP",GBP);
         change.putExtra("RUB",RUB);
         change.putExtra("JPY",JPY);
         startActivityForResult(change,1);
    }


    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.rate, menu);
        return  super.onCreateOptionsMenu(menu);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode==1&&resultCode==2){
            Bundle bundle = data.getExtras();
            GBP=bundle.getFloat("GBP1",0.1f);
            RUB=bundle.getFloat("RUB1",0.2f);
            JPY=bundle.getFloat("JPY1",0.3f);
            SharedPreferences sharedPreferences=getSharedPreferences("open",Activity.MODE_PRIVATE);
            SharedPreferences.Editor editor=sharedPreferences.edit();
            editor.putFloat("rate_GBP",GBP);
            editor.putFloat("rate_RUB",RUB);
            editor.putFloat("rate_JPY",JPY);
           editor.commit();

        }
            super.onActivityResult(requestCode, resultCode, data);
    }
}

