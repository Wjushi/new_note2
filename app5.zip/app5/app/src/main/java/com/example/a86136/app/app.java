package com.example.a86136.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class app extends AppCompatActivity implements Runnable {
    private final String TAG="Rate";
    private float dollarRate =0.1f;
    private float euroRate =0.2f;
    private float wonRate =0.3f;
    private String updata="";

    EditText rmb;
    TextView show;
    Handler handler;

    public app() throws IOException {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app);
        rmb =(EditText)findViewById(R.id.rmb);
        show =(TextView)findViewById(R.id.showOut);
        SharedPreferences sharedPreferences = getSharedPreferences("myrate", Activity.MODE_PRIVATE);
        dollarRate=sharedPreferences.getFloat("dollar_rate",0.0f);
        euroRate=sharedPreferences.getFloat("euro_rate",0.0f);
        wonRate=sharedPreferences.getFloat("won_rate",0.0f);
        updata=sharedPreferences.getString("updata","");
         Date today = Calendar.getInstance().getTime();
        SimpleDateFormat sdf= new SimpleDateFormat("yyyy-MM-dd");
        final String todaystr=sdf.format(today);

        Log.i(TAG,"openOne:dollarRate="+dollarRate);
        Log.i(TAG,"openOne:euroRate="+euroRate);
        Log.i(TAG,"openOne:wonRate="+wonRate);
        Log.i(TAG,"openOne:updata="+updata);
        Log.i(TAG,"openOne:");
        if(todaystr.equals(updata)){
            Log.i(TAG,"openOne:需要更新");
            Thread t =new Thread(this);
            t.start();
        }else {
            Log.i(TAG,"openOne:不需要更新");
        }





         Thread t = new Thread(this);
         t.start();
        handler=new Handler(){
            public void handleMessage(Message msg){
                if (msg.what==5){
                    Bundle bdl=(Bundle)msg.obj;
                   dollarRate=bdl.getFloat("dollar.rate");
                    euroRate=bdl.getFloat("euro.rate");
                    wonRate=bdl.getFloat("won.rate");
                    Log.i(TAG,"handleMessage:dollarRate="+dollarRate);
                    Log.i(TAG,"handleMessage:euroRate="+euroRate);
                    Log.i(TAG,"handleMessage:wonRate="+wonRate);

                    SharedPreferences sharedPreferences = getSharedPreferences("myrate", Activity.MODE_PRIVATE);
                    SharedPreferences.Editor editor=sharedPreferences.edit();

                    editor.putString("updata",todaystr);
                    editor.apply();
                    Toast.makeText(app.this,"汇率更新",Toast.LENGTH_SHORT).show();
                }super.handleMessage(msg);

            }};



        }
        public void onClick(View btn){
            String str=rmb.getText().toString();
            float r =0;
            if(str.length()>0){
             r = Float.parseFloat(str);}else{Toast.makeText(this,"请输入内容",Toast.LENGTH_SHORT).show();
            }
            Log.i(TAG,"onClick:r="+r);
             if(btn.getId()==R.id.btn_dollar){
                float val = r *(1/6.7f);
                show.setText(String .format("%.2f",r*dollarRate));
            }
            else if(btn.getId()==R.id.btn_euro){
                float val = r * (1/11f);
                show.setText(String .format("%.2f",r*euroRate));
            }
            else{
                float val = r * 500;
                show.setText(String .format("%.2f",r*wonRate));
            } }
          public void openOne(View btn){
           Intent config = new Intent(this,ConfigActivity.class);
              config.putExtra("dollar_rate_key",dollarRate);
              config.putExtra("euro_rate_key",euroRate);
              config.putExtra("won_rate_key",wonRate);


              Log.i(TAG,"openOne:dollarRate="+dollarRate);
              Log.i(TAG,"openOne:euroRate="+euroRate);
              Log.i(TAG,"openOne:wonRate="+wonRate);
              startActivityForResult(config,1);

          }
          public boolean onCreateOptionsMenu(Menu menu){
            getMenuInflater().inflate(R.menu.rate,menu);
            return true;

          }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode==1&&resultCode==2){
            Bundle bundle=data.getExtras();
            dollarRate=bundle.getFloat("key_dollar",0.1f);
            euroRate=bundle.getFloat("key_euro",0.1f);
            wonRate=bundle.getFloat("key_won",0.1f);
            Log.i(TAG,"onActivityResult="+dollarRate);
            Log.i(TAG,"onActivityResult="+euroRate);
            Log.i(TAG,"onActivityResult="+wonRate);

            SharedPreferences sharedPreferences = getSharedPreferences("myrate", Activity.MODE_PRIVATE);
            SharedPreferences.Editor editor=sharedPreferences.edit();
            editor.putFloat("dollar_rate",dollarRate);
            editor.putFloat("euro_rate",euroRate);
            editor.putFloat("won_rate",wonRate);
            editor.commit();
            Log.i(TAG,"onActivityResult：数据已保存到sharedPreferences");

        }
        super.onActivityResult(requestCode, resultCode, data);
    }
    public void run() {
        Log.i(TAG, "");
        try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Bundle bundle=new Bundle();


        /*URL url = null;
        try {
            url = new URL("view-source:http://www.usd-cny.com/icbc.htm");
            HttpURLConnection http = (HttpURLConnection) url.openConnection();
            InputStream in = http.getInputStream();
            String html = inputStream2String(in);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }*/
        Document doc = null;
        try {
            doc = Jsoup.connect("http://www.usd-cny.com/bankofchina.htm").get();
            Log.i(TAG,"run:"+doc.title());
            Elements tables=doc.getElementsByTag("table");

           /* int i =1;
            for( Element table:tables){
                Log.i(TAG,"run:table["+i+"]="+table);
                i++;
            }*/

             Element table1=tables.get(0);
              Log.i(TAG, "run:table1="+table1);
            Elements tds=table1.getElementsByTag("td" );
            for(int i=0;i<tds.size();i+=6){
                Element td1=tds.get(i);
                Element td2=tds.get(i+5);
                String str=td1.text();
                String val=td2.text();
                if("美元".equals(str)){
                    bundle.putFloat("dollar.rate",100f/Float.parseFloat(val)); }
                else if("欧元".equals(str)){
                    bundle.putFloat("euro.rate",100f/Float.parseFloat(val)); }
                else if("韩元".equals(str)   ){
                    bundle.putFloat("won.rate",100f/Float.parseFloat(val)); }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } Message msg = handler.obtainMessage(5);
        msg.obj = bundle;
        handler.sendMessage(msg);
        }

private String inputStream2String(InputStream inputStream) throws IOException {
final int bufferSize = 1024;
final char[] buffer = new char[bufferSize];
final StringBuilder out = new StringBuilder();
Reader in = new InputStreamReader(inputStream, "gb2312");
for (; ; ) {
int rsz = in.read(buffer, 0, buffer.length);
if (rsz < 0) {
break; }
return out.toString();
}          return null;
    }}



