package com.example.a86136.app;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class frame_home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_frame_home);
    }
}
