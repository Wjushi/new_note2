package com.example.a86136.app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Open extends AppCompatActivity {
     EditText GBPtext;
     EditText RUBtext;
     EditText JPYtext;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_open);
        Intent intent = getIntent();
        Float newGBP=intent.getFloatExtra("GBP",0.0f);
        Float newRUB=intent.getFloatExtra("RUB",0.0f);
        Float newJPY=intent.getFloatExtra("JPY",0.0f);

        GBPtext=(EditText)findViewById(R.id.open1);
        RUBtext=(EditText)findViewById(R.id.open2);
        JPYtext=(EditText)findViewById(R.id.open3);

        GBPtext.setText(String.valueOf(newGBP));
        RUBtext.setText(String.valueOf(newRUB));
        JPYtext.setText(String.valueOf(newJPY));

    }
    public void returnClick(View r){
        float newGBP2 =Float.parseFloat(GBPtext.getText().toString());
        float newRUB2 =Float.parseFloat(RUBtext.getText().toString());
        float newJPY2 =Float.parseFloat(JPYtext.getText().toString());
        Intent intent =getIntent();
        Bundle bdl=new Bundle();
        bdl.putFloat("GBP1",newGBP2 );
        bdl.putFloat("RUB1",newRUB2);
        bdl.putFloat("JPY1",newJPY2 );
        intent.putExtras(bdl);
        setResult(2,intent);
        finish();




    }
}
